/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Devika Oad
 */
@Entity
@Table(name = "population")
@NamedQueries({
    @NamedQuery(name = "Population.findAll", query = "SELECT p FROM Population p"),
    @NamedQuery(name = "Population.findByPid", query = "SELECT p FROM Population p WHERE p.pid = :pid"),
    @NamedQuery(name = "Population.findByYear", query = "SELECT p FROM Population p WHERE p.year = :year"),
    @NamedQuery(name = "Population.findByAdmPopulation", query = "SELECT p FROM Population p WHERE p.admPopulation = :admPopulation"),
    @NamedQuery(name = "Population.findByAdfPopulation", query = "SELECT p FROM Population p WHERE p.adfPopulation = :adfPopulation"),
    @NamedQuery(name = "Population.findByMcPopulation", query = "SELECT p FROM Population p WHERE p.mcPopulation = :mcPopulation"),
    @NamedQuery(name = "Population.findByFcPopulation", query = "SELECT p FROM Population p WHERE p.fcPopulation = :fcPopulation"),
    @NamedQuery(name = "Population.findByPopulationBp", query = "SELECT p FROM Population p WHERE p.populationBp = :populationBp")})
public class Population implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "pid")
    private Integer pid;
    @Basic(optional = false)
    @NotNull
    @Column(name = "year")
    private int year;
    @Basic(optional = false)
    @NotNull
    @Column(name = "adm_population")
    private int admPopulation;
    @Basic(optional = false)
    @NotNull
    @Column(name = "adf_population")
    private int adfPopulation;
    @Basic(optional = false)
    @NotNull
    @Column(name = "mc_population")
    private int mcPopulation;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fc_population")
    private int fcPopulation;
    @Basic(optional = false)
    @NotNull
    @Column(name = "population_bp")
    private int populationBp;
    @JoinColumn(name = "did", referencedColumnName = "did")
    @ManyToOne(optional = false)
    private District did;

    public Population() {
    }

    public Population(Integer pid) {
        this.pid = pid;
    }

    public Population(Integer pid, int year, int admPopulation, int adfPopulation, int mcPopulation, int fcPopulation, int populationBp) {
        this.pid = pid;
        this.year = year;
        this.admPopulation = admPopulation;
        this.adfPopulation = adfPopulation;
        this.mcPopulation = mcPopulation;
        this.fcPopulation = fcPopulation;
        this.populationBp = populationBp;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getAdmPopulation() {
        return admPopulation;
    }

    public void setAdmPopulation(int admPopulation) {
        this.admPopulation = admPopulation;
    }

    public int getAdfPopulation() {
        return adfPopulation;
    }

    public void setAdfPopulation(int adfPopulation) {
        this.adfPopulation = adfPopulation;
    }

    public int getMcPopulation() {
        return mcPopulation;
    }

    public void setMcPopulation(int mcPopulation) {
        this.mcPopulation = mcPopulation;
    }

    public int getFcPopulation() {
        return fcPopulation;
    }

    public void setFcPopulation(int fcPopulation) {
        this.fcPopulation = fcPopulation;
    }

    public int getPopulationBp() {
        return populationBp;
    }

    public void setPopulationBp(int populationBp) {
        this.populationBp = populationBp;
    }

    public District getDid() {
        return did;
    }

    public void setDid(District did) {
        this.did = did;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pid != null ? pid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Population)) {
            return false;
        }
        Population other = (Population) object;
        if ((this.pid == null && other.pid != null) || (this.pid != null && !this.pid.equals(other.pid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Population[ pid=" + pid + " ]";
    }
    
}
