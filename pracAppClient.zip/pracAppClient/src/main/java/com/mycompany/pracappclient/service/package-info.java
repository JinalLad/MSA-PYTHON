
/**
 * Restful services here
 */
package com.mycompany.pracappclient.service;