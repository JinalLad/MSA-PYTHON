/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package client;

import entity.District;
import entity.Population;
import entity.State;
import java.util.Collection;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import org.eclipse.microprofile.rest.client.annotation.ClientHeaderParam;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

/**
 *
 * @author Devika Oad
 */
//@RegisterRestClient(baseUri = "http://localhost:8080/pracApp/rest/example")
//for payra micro
@RegisterRestClient(baseUri = "http://desktop-o3k6jmo:8081/pracApp/")
public interface ApiInterface {
    
    @GET
    @Path("getstatedata")
    //@Produces(MediaType.APPLICATION_JSON)
    public Collection<State> getstatedata();
    
    @GET
    @Path("getdistrictdata")
    //@Produces(MediaType.APPLICATION_JSON)
    @ClientHeaderParam(name="authorization" ,value="Bearer eyJraWQiOiJqd3Qua2V5IiwidHlwIjoiSldUIiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiJkdWtlIiwidXBuIjoiZHVrZSIsImF1dGhfdGltZSI6MTY2ODc1ODY3NiwiaXNzIjoiYWlyaGFja3MiLCJncm91cHMiOlsiYWRtaW4iXSwiZXhwIjoxNjY4ODU4Njc2LCJpYXQiOjE2Njg3NTg2NzYsImp0aSI6IjQyIn0.HyHFiPDCmgX8ic5EepS7pdz1Gsue4nmuT7cQhbE_jB9vA5MTjm0k0Q8Qe5BEPuqUEKUlBPMzoe5qJUWFzac1RwozZ0EmwmtOH2k4CLkrS-2wJL8JGCpQnewAU4ffn3pI6kdJzRmq23v7W60GfzCjugpYp6Lfdbu6pJb5PcelkVn87cJceAq319djrNReLY6R3-pCxUvlma1f9sNuVzw3aXUOZqAHuYxHQRMlWQTuTFdLYFlvpyKlu7RNhlDtYbghIr7Rdy0lFZak6AAqtuPnnRc_WI_wGgN14gL7CqgepQD2l7diuSiOtcIozVCAxsPoCdsm_rgPQ5wIQci99rJkVg")
    public Collection<District> getdistrictdata();
    
    @GET
    @Path("getpopulationdata")
    //@Produces(MediaType.APPLICATION_JSON)
    @ClientHeaderParam(name="authorization" ,value="Bearer eyJraWQiOiJqd3Qua2V5IiwidHlwIjoiSldUIiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiJkdWtlIiwidXBuIjoiZHVrZSIsImF1dGhfdGltZSI6MTY2ODc1ODY3NiwiaXNzIjoiYWlyaGFja3MiLCJncm91cHMiOlsiYWRtaW4iXSwiZXhwIjoxNjY4ODU4Njc2LCJpYXQiOjE2Njg3NTg2NzYsImp0aSI6IjQyIn0.HyHFiPDCmgX8ic5EepS7pdz1Gsue4nmuT7cQhbE_jB9vA5MTjm0k0Q8Qe5BEPuqUEKUlBPMzoe5qJUWFzac1RwozZ0EmwmtOH2k4CLkrS-2wJL8JGCpQnewAU4ffn3pI6kdJzRmq23v7W60GfzCjugpYp6Lfdbu6pJb5PcelkVn87cJceAq319djrNReLY6R3-pCxUvlma1f9sNuVzw3aXUOZqAHuYxHQRMlWQTuTFdLYFlvpyKlu7RNhlDtYbghIr7Rdy0lFZak6AAqtuPnnRc_WI_wGgN14gL7CqgepQD2l7diuSiOtcIozVCAxsPoCdsm_rgPQ5wIQci99rJkVg")
    public Collection<Population> getpopulationdata();
}
