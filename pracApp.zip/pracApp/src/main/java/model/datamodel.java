/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import entity.District;
import entity.Population;
import entity.State;
import java.util.Collection;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Devika Oad
 */
public class datamodel {
    @PersistenceContext(unitName = "com.mycompany_pracApp_war_1.0-SNAPSHOTPU")
    
    EntityManager em;
    
    public Collection<District> getdistrictdata()
    {
        return em.createNamedQuery("District.findAll").getResultList();
    }
    
    public Collection<State> getstatedata()
    {
        return em.createNamedQuery("State.findAll").getResultList();
    }
    
    public Collection<Population> getpopulationdata()
    {
        return em.createNamedQuery("Population.findAll").getResultList();
    }
}
