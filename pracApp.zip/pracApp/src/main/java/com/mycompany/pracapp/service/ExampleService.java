package com.mycompany.pracapp.service;

import entity.District;
import entity.Population;
import entity.State;
import java.util.Collection;
import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;
import model.datamodel;

@Path("/example")
public class ExampleService {

    @Inject datamodel dm;
    
    @GET
    @Path("getstatedata")
    //@Produces(MediaType.APPLICATION_JSON)
    @RolesAllowed("admin")
    public Collection<State> getstatedata()
    {
        return dm.getstatedata();
    }
    
    @GET
    @Path("getdistrictdata")
    //Produces(MediaType.APPLICATION_JSON)
    @RolesAllowed("admin")
    public Collection<District> getdistrictdata()
    {
        return dm.getdistrictdata();
    }

    @GET
    @Path("getpopulationdata")
    //@Produces(MediaType.APPLICATION_JSON)
    @RolesAllowed("admin")
    public Collection<Population> getpopulationdata()
    {
        return dm.getpopulationdata();
    }
    
    
    @GET
    public Response get() {
        return Response.ok("Hello, world!").build();
    }

}
