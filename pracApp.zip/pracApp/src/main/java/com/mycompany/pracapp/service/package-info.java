
/**
 * Restful services here
 */
package com.mycompany.pracapp.service;